package com.example.lab_week_01

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputLayout

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Hubungkan dengan komponen di layout
        val etName = findViewById<EditText>(R.id.etName)
        val tilName = findViewById<TextInputLayout>(R.id.tilName)
        val etStudentNumber = findViewById<EditText>(R.id.etStudentNumber)
        val tilStudentNumber = findViewById<TextInputLayout>(R.id.tilStudentNumber)
        val btnSubmit = findViewById<Button>(R.id.btnSubmit)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        btnSubmit.setOnClickListener {
            val name = etName.text.toString().trim()
            val nim = etStudentNumber.text.toString().trim()

            // Reset error setiap kali tombol ditekan
            tilName.error = null
            tilStudentNumber.error = null

            // Validasi Nama kosong
            if (name.isEmpty()) {
                tilName.error = "Name cannot be empty"
                tvResult.text = ""
                return@setOnClickListener
            }

            // Validasi Student Number harus 11 digit angka
            if (!nim.matches(Regex("^\\d{11}$"))) {
                tilStudentNumber.error = "Student number has to be 11 digits long"
                tvResult.text = ""
                return@setOnClickListener
            }

            // Kalau semua valid → tampilkan hasil
            tvResult.text = "Hello, $name!\nStudent Number: $nim"
        }
    }
}
